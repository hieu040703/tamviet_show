@php
    $block  = $homeProductBrands ?? [];
    $widget = $block['widget'] ?? null;
    $items  = collect($block['items'] ?? []);
@endphp

@if($widget && $items->isNotEmpty())
    <div class="pb-4 md:container">
        <div class="block-title flex items-center p-4 md:px-0">
            <h4 class="font-semibold flex flex-1 text-base md:text-[20px]">
                {{ $widget->name ?? 'Thương hiệu nổi bật' }}
            </h4>
            <div>
                <a
                    class="relative flex justify-center border-0 bg-transparent text-sm font-normal text-hyperLink outline-none md:hover:text-primary-600 md:text-base"
                    href="/thuong-hieu"
                >
                    Xem thêm
                </a>
            </div>
        </div>
        <div class="w-full">
            <div class="relative flex h-full w-full items-center">
                <div
                    class="swiper swiper-horizontal custom-swiper-navigation w-full !mx-0 overflow-hidden !px-4 md:!px-0"
                >
                    <div class="swiper-wrapper">
                        @foreach($items as $item)
                            @php
                                $image = $item->image
                                    ? asset('storage/'.$item->image)
                                    : asset('backend/img/not-found.jpg');
                            @endphp
                            <div class="swiper-slide mr-2 !w-[126px] md:mr-4 md:!w-[288px]">
                                <a href="{{ router_link('categories', $item->id) }}">
                                    <div class="h-full w-full">
                                        <img
                                            class="h-full w-full rounded-sm object-contain"
                                            src="{{ $image }}"
                                            alt="{{ $item->name }}"
                                            width="500"
                                            height="500"
                                            loading="lazy"
                                            decoding="async"
                                        >
                                    </div>
                                </a>
                            </div>
                        @endforeach
                        <div class="swiper-slide mr-2 !w-[126px] md:mr-4 md:!w-[288px]">
                            <a href="http://phongkhamtaimuihongnhi.com/" target="_blank" rel="noopener noreferrer">
                                <div class="h-full w-full">
                                    <img
                                        class="h-full w-full rounded-sm object-contain"
                                        src="{{ asset('frontend/assets/image/brand/brand-1.png') }}"
                                        alt="phòng khám tâm việt"
                                        width="500"
                                        height="500"
                                        loading="lazy"
                                        decoding="async"
                                    >
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-button-next"></div>
                </div>
                <button
                    data-area="left"
                    data-size="sm"
                    type="button"
                    class="relative flex justify-center outline-none font-semibold focus:ring-primary-300 text-sm bg-transparent text-inherit border-0 hover:text-primary-500 focus:text-primary-500 custom-swiper-button-prev h-10 w-10 p-[10px]"
                >
                    <span class="p-icon inline-flex align-[-0.125em] justify-center max-h-full max-w-full w-8 h-8">
                        <svg viewBox="0 0 24 24" fill="none"
                             xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M6.29231 12.7138L15.2863 21.7048C15.6809 22.0984 16.3203 22.0984 16.7159 21.7048C17.1106 21.3111 17.1106 20.6717 16.7159 20.2781L8.43539 12.0005L16.7149 3.72293C17.1096 3.32928 17.1096 2.68989 16.7149 2.29524C16.3203 1.90159 15.6799 1.90159 15.2853 2.29524L6.29131 11.2861C5.90273 11.6757 5.90273 12.3251 6.29231 12.7138Z"
                                fill="currentColor"></path>
                        </svg>
                    </span>
                </button>
                <button
                    data-area="right"
                    data-size="sm"
                    type="button"
                    class="relative flex justify-center outline-none font-semibold text-sm bg-transparent text-inherit border-0 hover:text-primary-500 focus:text-primary-500 custom-swiper-button-next h-10 w-10 p-[10px]"
                >
                    <span class="p-icon inline-flex align-[-0.125em] justify-center max-h-full max-w-full w-8 h-8">
                        <svg viewBox="0 0 24 24" fill="none"
                             xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M17.2137 11.2862L8.21971 2.29524C7.82506 1.90159 7.18567 1.90159 6.79002 2.29524C6.39537 2.68889 6.39537 3.32829 6.79002 3.72194L15.0706 11.9995L6.79102 20.2771C6.39637 20.6707 6.39637 21.3101 6.79102 21.7048C7.18567 22.0984 7.82606 22.0984 8.22071 21.7048L17.2147 12.7139C17.6032 12.3243 17.6032 11.6749 17.2137 11.2862Z"
                                fill="currentColor"></path>
                        </svg>
                    </span>
                </button>
            </div>
        </div>
    </div>
@endif
<script>
    document.addEventListener('DOMContentLoaded', function () {
        if (typeof Swiper === 'undefined') return;

        var brandSwipers = document.querySelectorAll('.pb-4.md\\:container .custom-swiper-navigation');
        if (!brandSwipers.length) return;

        brandSwipers.forEach(function (el) {
            var wrapper = el.closest('.relative') || el.parentElement || document;
            var customPrevBtn = wrapper.querySelector('.custom-swiper-button-prev');
            var customNextBtn = wrapper.querySelector('.custom-swiper-button-next');

            new Swiper(el, {
                slidesPerView: 'auto',
                spaceBetween: 8,
                loop: false,
                watchOverflow: true,
                autoplay: false,
                navigation: {
                    prevEl: customPrevBtn || el.querySelector('.swiper-button-prev'),
                    nextEl: customNextBtn || el.querySelector('.swiper-button-next')
                },
                breakpoints: {
                    768: {
                        spaceBetween: 16
                    }
                }
            });
        });
    });
</script>


